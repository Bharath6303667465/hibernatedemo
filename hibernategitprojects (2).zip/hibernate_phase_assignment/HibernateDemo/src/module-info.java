/**
 * 
 */
/**
 * @author Bharath
 *
 */
module HibernateDemo {
	requires jakarta.persistence;
	requires org.hibernate.orm.core;
}